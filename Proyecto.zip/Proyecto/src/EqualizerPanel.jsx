import React from "react";
import {
  AudioLines,
  RotateCcw,
  Power,
  SlidersHorizontal,
} from "lucide-react";

const BANDS = [
  { label: "50", unit: "Hz", description: "Subgraves" },
  { label: "125", unit: "Hz", description: "Graves" },
  { label: "315", unit: "Hz", description: "Graves medios" },
  { label: "750", unit: "Hz", description: "Medios" },
  { label: "2.2", unit: "kHz", description: "Medios altos" },
  { label: "6", unit: "kHz", description: "Agudos" },
  { label: "16", unit: "kHz", description: "Superagudos" },
];

const PRESETS = {
  Flat: [0, 0, 0, 0, 0, 0, 0],
  Rock: [4, 3, -1, -2, 2, 4, 5],
  Pop: [-1, 2, 3, 2, 0, 2, 3],
  Jazz: [3, 2, 0, 2, -1, 2, 3],
  Bass: [7, 5, 3, 0, -1, 0, 1],
  Vocal: [-2, -1, 1, 4, 4, 2, 0],
};

export default function EqualizerPanel({
  values = [0, 0, 0, 0, 0, 0, 0],
  enabled = true,
  streamingMode = false,
  onChange,
  onToggle,
  onReset,
  onPreset,
}) {
  const applyPreset = (name) => {
    const preset = PRESETS[name];

    if (preset && onPreset) {
      onPreset([...preset]);
    } else if (preset && onChange) {
      preset.forEach((value, index) => {
        onChange(index, value);
      });
    }
  };

  const reset = () => {
    if (onReset) {
      onReset();
    } else if (onChange) {
      BANDS.forEach((_, index) => onChange(index, 0));
    }
  };

  return (
    <section className="eq-panel">
      <header className="eq-panel__header">
        <div className="eq-panel__title">
          <div className="eq-panel__icon">
            <AudioLines size={20} />
          </div>

          <div>
            <h2>GRAPHIC EQUALIZER</h2>
            <p>7-BAND DIGITAL AUDIO PROCESSOR</p>
          </div>
        </div>

        <button
          type="button"
          className={`eq-power ${
            enabled ? "eq-power--on" : ""
          }`}
          onClick={onToggle}
          aria-pressed={enabled}
          title={enabled ? "Desactivar EQ" : "Activar EQ"}
        >
          <Power size={16} />
          <span>{enabled ? "ON" : "OFF"}</span>
        </button>
      </header>

      <div className="eq-panel__presets">
        <span className="eq-panel__label">
          <SlidersHorizontal size={14} />
          PREAJUSTES
        </span>

        <div className="eq-preset-buttons">
          {Object.keys(PRESETS).map((name) => (
            <button
              type="button"
              key={name}
              className="eq-preset"
              onClick={() => applyPreset(name)}
              disabled={!enabled}
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      <div
        className={`eq-bands ${
          !enabled ? "eq-bands--disabled" : ""
        }`}
      >
        {BANDS.map((band, index) => {
          const value = Number(values[index] ?? 0);

          return (
            <div className="eq-band" key={band.label}>
              <div className="eq-band__value">
                {streamingMode ? (
                  <span className="eq-hidden-value">•••</span>
                ) : (
                  <>
                    {value > 0 ? "+" : ""}
                    {value.toFixed(0)}
                    <span className="eq-band__db">dB</span>
                  </>
                )}
              </div>

              <div className="eq-band__slider-area">
                <span className="eq-band__limit">+12</span>

                <div className="eq-band__track">
                  <div className="eq-band__zero" />

                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="1"
                    value={value}
                    orient="vertical"
                    aria-label={`${band.label} ${band.unit}, ${band.description}`}
                    title={`${band.description}: ${band.label} ${band.unit}`}
                    onChange={(event) => {
                      onChange?.(index, Number(event.target.value));
                    }}
                    disabled={!enabled}
                    style={{
                      "--eq-position": `${((value + 12) / 24) * 100}%`,
                    }}
                  />
                </div>

                <span className="eq-band__limit">-12</span>
              </div>

              <div className="eq-band__frequency">
                <strong>{band.label}</strong>
                <span>{band.unit}</span>
              </div>

              <span className="eq-band__description">
                {band.description}
              </span>
            </div>
          );
        })}
      </div>

      <footer className="eq-panel__footer">
        <div className="eq-panel__range">
          <span>GAIN RANGE</span>
          <strong>−12 dB / +12 dB</strong>
        </div>

        <button
          type="button"
          className="eq-reset"
          onClick={reset}
        >
          <RotateCcw size={14} />
          RESET
        </button>
      </footer>
    </section>
  );
}